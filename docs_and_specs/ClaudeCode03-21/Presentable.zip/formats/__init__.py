"""
Format definitions for Presentable Object Model (POM) package.

This package contains YAML format definition files for different
serialization formats supported by the POM package.
"""
