"""
Test models for the Presentable Object Model (POM) package.

This package contains model classes used for testing the POM package.
"""
